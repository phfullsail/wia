// JavaScript Document

console.log("The canvas is not supported");


webshims.polyfill("canvas"); 