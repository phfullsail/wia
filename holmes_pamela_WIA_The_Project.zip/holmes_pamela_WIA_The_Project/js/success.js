// JavaScript Document


console.log("The canvas is supported, nothing else to do.");
